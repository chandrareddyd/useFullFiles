package com.dbs.cst.ircp.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "TBL_IRAS_FILE_HEADER")
public class IRASHeaderInput {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "FILE_ID")
	private Long fileId;
	
	@Column(name = "READ_TIME", nullable = true, length = 8)
	private Date readTime;
	
	@Column(name = "COMPLETE_TIME", nullable = true, length = 8)
	private Date completeTime;
	
	@Column(name = "ORG_NAME", nullable = true, length = 4)
	private String orgName;
	
	@Column(name = "TRANSACTION_DATE", nullable = true, length = 8)
	private String transDate;
	
	@Column(name = "HEADER_VALID", nullable = true, length = 1)
	private String headerValid;
	
	@Column(name = "NO_OF_APPMT", nullable = true, length = 6)
	private Long noOfAppmt;
	
	@Column(name = "TOTAL_APPMT_AMOUNT", nullable = true, length = 15)
	private double appmtAmount;
	
	@Column(name = "NRIC_HASH", nullable = true, length = 16)
	private Long nricHash;
	
	@Column(name = "AMOUNT_HASH", nullable = true, length = 7)
	private Double amountHash;
	
	@Column(name = "NO_OF_RELEASE", nullable = true, length = 6)
	private Long noOfRelease;
	
	@Column(name = "TOTAL_RELEASE_AMOUNT", nullable = true, length = 15)
	private Double releaseAmount;
	
	@Column(name = "TRAILER_VALID", nullable = true, length = 1)
	private String trailerValid;
	

	public IRASHeaderInput() {
	}


	public IRASHeaderInput(Long fileId, Date readTime, Date completeTime, String orgName, String transDate,
			String headerValid, Long noOfAppmt, double appmtAmount, Long nricHash, Double amountHash, Long noOfRelease,
			Double releaseAmount, String trailerValid) {
		super();
		this.fileId = fileId;
		this.readTime = readTime;
		this.completeTime = completeTime;
		this.orgName = orgName;
		this.transDate = transDate;
		this.headerValid = headerValid;
		this.noOfAppmt = noOfAppmt;
		this.appmtAmount = appmtAmount;
		this.nricHash = nricHash;
		this.amountHash = amountHash;
		this.noOfRelease = noOfRelease;
		this.releaseAmount = releaseAmount;
		this.trailerValid = trailerValid;
	}


	public Long getFileId() {
		return fileId;
	}


	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}


	public Date getReadTime() {
		return readTime;
	}


	public void setReadTime(Date readTime) {
		this.readTime = readTime;
	}


	public Date getCompleteTime() {
		return completeTime;
	}


	public void setCompleteTime(Date completeTime) {
		this.completeTime = completeTime;
	}


	public String getOrgName() {
		return orgName;
	}


	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}


	public String getTransDate() {
		return transDate;
	}


	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}


	public String getHeaderValid() {
		return headerValid;
	}


	public void setHeaderValid(String headerValid) {
		this.headerValid = headerValid;
	}


	public Long getNoOfAppmt() {
		return noOfAppmt;
	}


	public void setNoOfAppmt(Long noOfAppmt) {
		this.noOfAppmt = noOfAppmt;
	}


	public double getAppmtAmount() {
		return appmtAmount;
	}


	public void setAppmtAmount(double appmtAmount) {
		this.appmtAmount = appmtAmount;
	}


	public Long getNricHash() {
		return nricHash;
	}


	public void setNricHash(Long nricHash) {
		this.nricHash = nricHash;
	}


	public Double getAmountHash() {
		return amountHash;
	}


	public void setAmountHash(Double amountHash) {
		this.amountHash = amountHash;
	}


	public Long getNoOfRelease() {
		return noOfRelease;
	}


	public void setNoOfRelease(Long noOfRelease) {
		this.noOfRelease = noOfRelease;
	}


	public Double getReleaseAmount() {
		return releaseAmount;
	}


	public void setReleaseAmount(Double releaseAmount) {
		this.releaseAmount = releaseAmount;
	}


	public String getTrailerValid() {
		return trailerValid;
	}


	public void setTrailerValid(String trailerValid) {
		this.trailerValid = trailerValid;
	}


	@Override
	public String toString() {
		return "IRASHeaderInput [fileId=" + fileId + ", readTime=" + readTime + ", completeTime=" + completeTime
				+ ", orgName=" + orgName + ", transDate=" + transDate + ", headerValid=" + headerValid + ", noOfAppmt="
				+ noOfAppmt + ", appmtAmount=" + appmtAmount + ", nricHash=" + nricHash + ", amountHash=" + amountHash
				+ ", noOfRelease=" + noOfRelease + ", releaseAmount=" + releaseAmount + ", trailerValid=" + trailerValid
				+ "]";
	}

	
	
}