package com.dbs.cst.ircp.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.hibernate.Session;

import com.dbs.cst.ircp.models.IRASDetailsInput;
import com.dbs.cst.ircp.models.IRASHeaderInput;
/**
 * @author chandrareddy
 * @params IRASInputFile.txt
 * @exception FileNotFoundException and SQLException
 * @description It will process the file and store into MariaDB
 * 
 *
 */
public class FileController {


	private Double Nrichash =0d;
	private double appTotal = 0d;
	private Long releaseCount = 0l;
	private Double releaseTotal = 0d;
	private Long appmtCount = 0l;

	DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
	Date date = new Date();

	String currentDate = dateFormat.format((date));

	//@RequestMapping(value = "/iras", method = RequestMethod.GET)
	public void processFile() {

		try {

			IRASHeaderInput irasHeader = new IRASHeaderInput();
			IRASDetailsInput irasDetails;


			File file = null;
			try {
				file = new File(this.getClass().getResource("/IRASInputFile.txt").toURI());
			} catch (URISyntaxException e3) {
				// TODO Auto-generated catch block
				e3.printStackTrace();
			}

			String status = "";
			
			List<String> line = FileUtils.readLines(file, "UTF-8");
			
			int recordType = Integer.parseInt(line.get(0).substring(0, 1));
			String orgName = line.get(0).substring(1, 5);
			String trailerRecord = line.get(line.size() - 1);
			int trailerRecordType = Integer.parseInt(trailerRecord.substring(0, 1));
			String noOfAppmt = (trailerRecord.substring(1, 6));
			String appmtAmount = (trailerRecord.substring(7, 21));
			String nricHash = (trailerRecord.substring(22, 37));
			String amountHash = (trailerRecord.substring(38, 44));
			String noOfRelease = (trailerRecord.substring(45, 50));
			String releaseAmount = (trailerRecord.substring(51, 65));

			
			if(trailerRecordType == 9){
				irasHeader.setTrailerValid("Y");
				
			}else{
				irasHeader.setTrailerValid("N");
			}
			/**
			 * Create hibernate session and start transaction.
			 */
			Session session = HibernateUtil.getSessionFactory().openSession();
			session.beginTransaction();
			if (recordType == 0 && orgName.equals("IRAS") && trailerRecordType == 9) {

				System.out.println("Validation successful");
				status = "SUCCESS";
				irasHeader.setHeaderValid("Y");

				
				for (int i = 1; i < line.size() - 1; i++) {
					 irasDetails = new IRASDetailsInput();
					System.out.println(line.get(i).length());
					int recType = Integer.parseInt(line.get(i).substring(0, 1));
					irasDetails.setNric(line.get(i).substring(2, 17));
					
					String nric = line.get(i).substring(2, 17);
					String newNric = nric.replaceAll("([A-Za-z]{1})", "0");
					irasDetails.setNricReformat(newNric);
					
					try {
						irasDetails.setFileDate((Date)dateFormat.parse(currentDate));
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					
					irasDetails.setCaseId(line.get(i).substring(17, 26));
					irasDetails.setTaxType(Integer.parseInt(line.get(i).substring(26, 29)));
					irasDetails.setCustomerName(line.get(i).substring(29, 119));
					irasDetails.setAmountDue(Double.parseDouble(line.get(i).substring(120, 128)));
					try {
						irasDetails.setAppmtDate((Date)dateFormat.parse(line.get(i).substring(128, 136)));
					} catch (ParseException e1) {
						e1.printStackTrace();
					}

					if (recType == 2){
						try {
							irasDetails.setReleaseDate((Date)dateFormat.parse(line.get(i).substring(136, 144)));
							releaseCount++;
							releaseTotal = (double)irasDetails.getAmountDue();
							
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					if(recType == 1){
						appmtCount++;
						appTotal += irasDetails.getAmountDue();
					}
					irasDetails.setIsValid("Y");
					session.save(irasDetails);
				}

			} else {

				System.out.println("Validation failed");
				status = "Invalid Record";
				irasHeader.setHeaderValid("N");
				new IRASDetailsInput().setIsValid("N");
				

			}
			irasHeader.setOrgName(orgName);

			irasHeader.setTransDate(currentDate);
			irasHeader.setAmountHash(Double.parseDouble(amountHash));
			irasHeader.setAppmtAmount(appTotal);
			//irasHeader.setNoOfAppmt(Integer.parseInt(noOfAppmt));
			
			irasHeader.setNoOfAppmt(appmtCount);
			irasHeader.setNoOfRelease(releaseCount);
			
			//irasHeader.setNoOfRelease(Integer.parseInt(noOfRelease));
			
			irasHeader.setNricHash(Long.parseLong(nricHash));
			//irasHeader.setReleaseAmount(Long.parseLong(releaseAmount));
			
			irasHeader.setReleaseAmount(releaseTotal);
			try {
				irasHeader.setReadTime((Date)dateFormat.parse(currentDate));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				irasHeader.setCompleteTime((Date)dateFormat.parse(currentDate));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			session.save(irasHeader);
			session.getTransaction().commit();
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("#######################" + releaseTotal);

	}




}