package com.dbs.cst.ircp.utils;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
  
public class HibernateUtil {
  
    private static SessionFactory sessionFactory;
  
    private static SessionFactory buildSessionFactory() {
        try {
            // Create the SessionFactory from hibernate.cfg.xml
            return new Configuration().configure().buildSessionFactory();
        } catch (Throwable ex) {
            // Make sure you log the exception, as it might be swallowed
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }
  
    public static SessionFactory getSessionFactory() {
    	if (sessionFactory != null)
    		return sessionFactory;
    	else
    		return buildSessionFactory();
    }
  
    public static void shutdown() {
        // Close caches and connection pools
    	getSessionFactory().openSession().flush();
        getSessionFactory().openSession().clear();
        getSessionFactory().openSession().close();
    }
  
}