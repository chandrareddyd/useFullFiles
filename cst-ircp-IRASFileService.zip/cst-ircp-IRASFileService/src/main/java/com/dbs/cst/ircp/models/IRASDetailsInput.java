package com.dbs.cst.ircp.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TBL_IRAS_FILE_DETAILS")
public class IRASDetailsInput {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "FILE_ID")
	private Long fileId;

	//	@ManyToOne(targetEntity=IRASHeaderInput.class)
//    @JoinColumn(name = "FILE_ID", nullable = false)
//	private IRASHeaderInput fileId;
	
	@Column(name = "NRIC", nullable = true, length = 16)
	private String nric;
	
	@Column(name = "NRIC_REFORMATE", nullable = true, length = 16)
	private String nricReformat;
	
	@Column(name = "CASE_ID", nullable = true, length = 9)
	private String caseId;
	
	@Column(name = "TAX_TYPE", nullable = true, length = 3)
	private int taxType;
	
	@Column(name = "CUSTOMER_NAME", nullable = true, length = 90)
	private String customerName;
	
	@Column(name = "AMOUNT_DUE", nullable = true, length = 9)
	private Double amountDue;
	
	@Column(name = "APPMT_DATE", nullable = true, length = 8)
	private Date appmtDate;
	
	@Column(name = "RELEASE_DATE", nullable = true, length = 8)
	private Date releaseDate ;
	
	@Column(name = "FILE_DATE", nullable = true, length = 8)
	private Date fileDate;
	
	@Column(name = "IS_VALID", nullable = true, length = 1)
	private String isValid;
	
	@Column(name = "ERROR_CODE", nullable = true, length = 2)
	private int errorCode;
	
	
	public IRASDetailsInput() {
	}


	public IRASDetailsInput(Long fileId, String nric, String nricReformat, String caseId, int taxType,
			String customerName, Double amountDue, Date appmtDate, Date releaseDate, Date fileDate, String isValid,
			int errorCode) {
		super();
		this.fileId = fileId;
		this.nric = nric;
		this.nricReformat = nricReformat;
		this.caseId = caseId;
		this.taxType = taxType;
		this.customerName = customerName;
		this.amountDue = amountDue;
		this.appmtDate = appmtDate;
		this.releaseDate = releaseDate;
		this.fileDate = fileDate;
		this.isValid = isValid;
		this.errorCode = errorCode;
	}


	public Long getFileId() {
		return fileId;
	}


	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}


	public String getNric() {
		return nric;
	}


	public void setNric(String nric) {
		this.nric = nric;
	}


	public String getNricReformat() {
		return nricReformat;
	}


	public void setNricReformat(String nricReformat) {
		this.nricReformat = nricReformat;
	}


	public String getCaseId() {
		return caseId;
	}


	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}


	public int getTaxType() {
		return taxType;
	}


	public void setTaxType(int taxType) {
		this.taxType = taxType;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public Double getAmountDue() {
		return amountDue;
	}


	public void setAmountDue(Double amountDue) {
		this.amountDue = amountDue;
	}


	public Date getAppmtDate() {
		return appmtDate;
	}


	public void setAppmtDate(Date appmtDate) {
		this.appmtDate = appmtDate;
	}


	public Date getReleaseDate() {
		return releaseDate;
	}


	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}


	public Date getFileDate() {
		return fileDate;
	}


	public void setFileDate(Date fileDate) {
		this.fileDate = fileDate;
	}


	public String getIsValid() {
		return isValid;
	}


	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}


	public int getErrorCode() {
		return errorCode;
	}


	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}


	@Override
	public String toString() {
		return "IRASDetailsInput [fileId=" + fileId + ", nric=" + nric + ", nricReformat=" + nricReformat + ", caseId="
				+ caseId + ", taxType=" + taxType + ", customerName=" + customerName + ", amountDue=" + amountDue
				+ ", appmtDate=" + appmtDate + ", releaseDate=" + releaseDate + ", fileDate=" + fileDate + ", isValid="
				+ isValid + ", errorCode=" + errorCode + "]";
	}

	
}




