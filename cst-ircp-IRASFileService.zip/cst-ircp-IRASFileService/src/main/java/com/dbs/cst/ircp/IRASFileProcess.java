package com.dbs.cst.ircp;

import com.dbs.cst.ircp.utils.FileController;

public class IRASFileProcess {

	public static void main(String[] args) {
		FileController controller = new FileController();
		controller.processFile();
	}

}